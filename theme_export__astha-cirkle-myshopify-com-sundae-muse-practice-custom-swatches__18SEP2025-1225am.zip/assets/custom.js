$(document).ready(function () {
  $(".hero-back-slider").slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    dots: false,
    fade: true,
    speed: 400,
    autoplay: true,
    autoplaySpeed: 2500,
  });

  $(".hero-slider").slick({
    infinite: false,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: false,
    fade: true,
    speed: 1000,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          arrows: false,
          dots: true,
          dotsClass: "slick-dots custom-dots",
        },
      },
    ],
  });

  $(".trending-slider").slick({
    infinite: false,
    slidesToShow: 2,
    slidesToScroll: 2,
    arrows: false,
    dots: false,
    speed: 500,
    centerMode: false,
    adaptiveHeight: false,
    responsive: [
      {
        breakpoint: 641,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  });

  $(".product-slider-image").slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: false,
    dotsClass: "slick-dots custom-dots",
    speed: 500,
  });

  $(".card-slider-wrapper").slick({
    infinite: false,
    slidesToShow: 3,
    slidesToScroll: 3,
    arrows: true,
    dots: false,
    speed: 500,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 481,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  });

  $(".pdp-slider").slick({
    infinite: false,
    slidesToShow: 2,
    slidesToScroll: 2,
    arrows: true,
    dots: false,
    speed: 500,
    responsive: [
      {
        breakpoint: 1921,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 1281,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  });

  $(".close-popup, .popup-overlay").on("click", function () {
    $(".newslatter-popup").removeClass("popup-open");
  });

  // Filters
  $("body").on("click", ".filter-lable", function () {
    $(".filter-lable").removeClass("active");
    $(".filter-inner").slideUp();
    if (!$(this).next().is(":visible")) {
      $(this).next().slideDown();
      $(this).addClass("active");
    }
  });
  $("body").on("click", ".filter-var-lable", function () {
    $(".filter-var-lable").removeClass("active");
    $(".filter-var ul").slideUp();
    if (!$(this).next().is(":visible")) {
      $(this).next().slideDown();
      $(this).addClass("active");
    }
  });

  // $(".cm-add-bag").on("click", function (e) {
  //   e.preventDefault();
  //   $(".mob-size-selecter").addClass("active");
  // });
  // $(".close-size-popup, .add_cart").on("click", function () {
  //   $(".mob-size-selecter").removeClass("active");
  // });

  $(".cm-acc-title").click(function () {
    $(".cm-acc-title").removeClass("active");
    $(".cm-acc-desc").slideUp();
    if (!$(this).next().is(":visible")) {
      $(this).next().slideDown();
      $(this).addClass("active");
    }
  });

  $(".ds-accordion .acc-drop").click(function () {
    $(".pdp-ds-inner").toggleClass("active");
  });

  $(".close-icon").click(function () {
    $(".announcement-bar").slideUp();
    // if ($(window).width() > 991) {
    //   var mnh = 164 - $(".announcement-bar").outerHeight();
    //   console.log($(".hero-section").length);
    //    $(".hero-section").attr("style", "height: calc(100vh - " + mnh + "px)");
    // }
  });

  $(".menu-hemburger a").on("click", function (e) {
    e.preventDefault();
    $(".mobile-menu, body").addClass("active-menu");
  });
  $(".menu-overlay, .close-menu").on("click", function () {
    $(".mobile-menu, body").removeClass("active-menu");
    $(".cm-menu-inner").find(".has-children").removeClass("is-open");
  });

  $(".open-size-popup").on("click", function (e) {
    e.preventDefault();
    $(".size-guide-popup, body").addClass("active-popup");
  });
  $(".size-overlay, .guide-popup-close").on("click", function () {
    $(".size-guide-popup, body").removeClass("active-popup");
  });

  $(".header-search input").on("focus", function () {
    $(".header-bottom").addClass("active-search");
  });
  $(".close-search").on("click", function () {
    $(".header-bottom").removeClass("active-search");
  });

  // flag : says "remove class when click reaches background"
  var removeClass = true;

  // when clicking the button : toggle the class, tell the background to leave it as is
  $(".cart a").click(function (e) {
    e.preventDefault();
    $(".mini-cart, body").toggleClass("active-cart");
    recommendations();
    // removeClass = false;
  });

  // // when clicking the div : never remove the class
  // $("body").on('click','.mini-cart', function () {
  //   // removeClass = false;
  // });

  // when click event reaches "html" : remove class if needed, and reset flag
  $("body").on("click", ".close-cart", function (e) {
    e.preventDefault();
    // console.log(removeClass, 'removeClass')
    // if (removeClass) {
    $(".mini-cart, body").removeClass("active-cart");
    // }
    // removeClass = true;
  });

  // $(document).click(function() {
  //     $('.mini-cart').removeClass('active-cart');
  // });
  // $(".cart").click(function(event) {
  //     $('.mini-cart').addClass('active-cart');
  //     event.stopPropagation();
  // });

  // $(window)
  //   .on("resize", function () {
  //     // var rightposition = $(".head-bottom-inner").offset().left;
  //     $(".mini-cart").css("right", rightposition);
  //   })
  //   .resize();

  if ($(".trending-slider").length > 0) {
    $(window)
      .on("resize", function () {
        var leftposition = $(".new-ar-product").offset().left;
        $(".trending-slider .slick-list").css("padding-left", leftposition);
      })
      .resize();
  }

  // ==========================================================================
  //  ACCORDION TAB
  // ==========================================================================

  // tabbed content
  // http://www.entheosweb.com/tutorials/css/tabs.asp
  $(".tab_content").hide();
  $(".tab_content:first").show();

  /* if in tab mode */
  $("ul.tabs-main li").click(function () {
    $(".tab_content").hide();
    var activeTab = $(this).attr("rel");
    $("#" + activeTab).fadeIn();

    $("ul.tabs-main li").removeClass("active");
    $(this).addClass("active");

    $(".tab_drawer_heading").removeClass("d_active");
    $(".tab_drawer_heading[rel^='" + activeTab + "']").addClass("d_active");
  });
  /* if in drawer mode */
  $(".tab_drawer_heading").click(function () {
    $(".tab_content").hide();
    var d_activeTab = $(this).attr("rel");
    $("#" + d_activeTab).fadeIn();

    $(".tab_drawer_heading").removeClass("d_active");
    $(this).addClass("d_active");

    $("ul.tabs-main li").removeClass("active");
    $("ul.tabs-main li[rel^='" + d_activeTab + "']").addClass("active");
  });

  /* Extra class "tab_last" 
       to add border to right side
       of last tab */
  $("ul.tabs-main li").last().addClass("tab_last");

  /*accordian js start here*/
  // When any accordion title is clicked...
  $(".accordion__title").click(function () {
    const accordion_wrapper = $(this).parent();
    const accordion_content = $(this)
      .parent()
      .find(".accordion__content")
      .first();
    const accordion_open = "accordion--open";

    // If this accordion is already open
    if (accordion_wrapper.hasClass(accordion_open)) {
      accordion_content.slideUp(); // Close the content.
      accordion_wrapper.removeClass(accordion_open); // Remove the accordionm--open class.
    }
    // If this accordion is not already open
    else {
      accordion_content.slideDown(); // Show this accordion's content.
      accordion_wrapper.addClass(accordion_open); // Add the accordion--open class.
    }
  });

  /*accordian js end here*/

  // ==========================================================================
  //  Multi-level accordion nav
  // ==========================================================================
  $(".acnav__label").click(function () {
    var label = $(this);
    var parent = label.parent(".has-children");
    if (parent.hasClass("is-open")) {
      parent.removeClass("is-open");
    } else {
      parent.addClass("is-open");
    }
  });
  $(".back-menu").click(function () {
    $(this).parent().parent().parent().removeClass("is-open");
  });
  // ==========================================================================

  // ==========================================================================
  //  TAB VIEW
  // ==========================================================================

  $(".tabs a").click(function () {
    $(".panel").hide();
    $(".tabs a.active").removeClass("active");
    $(this).addClass("active");

    var panel = $(this).attr("href");
    $(panel).fadeIn(800);

    return false; // prevents link action
  }); // end click

  $(".tabs li:first a").click();
  // ==========================================================================

  $(window).scroll(function () {
    var sticky = $("header");
    var headerHeight = $("header").height();
    scroll = $(window).scrollTop();
    if (scroll >= 200) {
      sticky.addClass("fixed");
      $(".wrapper").css("margin-top", headerHeight + "px");
    } else {
      sticky.removeClass("fixed");
      $(".wrapper").css("margin-top", 0 + "px");
    }

    if ($(".index-template").length > 0) {
      var geth = $(".header-bottom").outerHeight();
      if (scroll >= geth) {
        $(".header-bottom").addClass("menu_fixed");
      } else {
        $(".header-bottom").removeClass("menu_fixed");
      }
    }
  });
  setTimeout(function () {
    $(".newslatter-popup").addClass("popup-open");
  }, 5000);

  $(window).on("load resize orientationchange", function () {
    var sliderheight = $(".pdp-slider").height();
    var pdpcontent = $(".pdp-details").height();
    if (sliderheight <= pdpcontent) {
      $(".product-details-slider").css("min-height", pdpcontent);
    } else {
      $(".product-details-slider").css("min-height", sliderheight);
    }
  });

  // sustainability tabs

  const tabLinks = document.querySelectorAll(".tab-link");
  const tabs = document.querySelectorAll(".sut-bottom-tab");
  function resetTabs() {
    tabLinks.forEach((link) => 
      link.classList.remove("active")
    );
    tabs.forEach((tab) => 
      tab.classList.remove("active")
    );
  }
  function activateTab(index) {
    resetTabs();
    tabLinks[index].classList.add("active");
    tabs[index].classList.add("active");
  }
  tabLinks.forEach((link, index) => {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      activateTab(index);
    });
  });
  if (tabLinks.length > 0) {
    activateTab(0);
    activateTab(1);
  }
});

// ************* Cart *****************
// Cart functions------

function updateCart() {
  // section rendering
  $.get("cart?section_id=main-cart", function (data) {
    console.log("Cart Data:", data);
    $("section.main_cart").html($(data).html());
  });

  $.get("cart?section_id=cart-drawer", function (data) {
    $("section.mini-cart").html($(data).html());
    $(".mini-cart-body").html($(data).find(".mini-cart-body").html());
  });

  //alternate template
  // $.get("/cart?view=cart-drawer", function (data) {
  //   $(".mini-cart-inner").html($(data).find(".mini-cart-inner"));
  // });
    updateCartTotal();
    recommendations();
}

function changeCount() {
  $.getJSON("/cart", function (cart) {
    console.log("cart count", cart.item_count);
    $(".cart-count").html(cart.item_count);
    $(".mini-cart-header h5 span").html(cart.item_count);
  });
}

$("body").on("change", ".mini-cart-inner .subscription-options", function (event) {
  var selectedPlan = $(event.target).find("option:selected").text().trim();
  console.log("Selected Plan:" , selectedPlan);
  $.getJSON("/cart.js", function (cart) {
    // Filter items according selling plan
    
    // var itemsToUpdate = cart.items.filter(item =>
    //   item.properties && item.properties.selling_plan !== undefined
    // );
    var itemsToUpdate = cart.items;
    var updateItem = (index) => {
      if (index >= itemsToUpdate.length) {
        console.log("All cart items updated.");
        updateCart();
      };

      var item = itemsToUpdate[index];
      console.log("Items:",item)
      var updatedProperties = {
        ...item.properties,
        selling_plan: selectedPlan
      };

      $.ajax({
        url: "/cart/change.js",
        method: "POST",
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({
          id: item.key,
          quantity: item.quantity,
          properties: updatedProperties
        }),
        success: function () {
          updateItem(index + 1);
        },
        error: function (err) {
          console.error("Error updating item:", item.key, err);
          updateItem(index + 1);
        }
      });
    };
    updateItem(0);
  });
});

$("body").on("click", ".product--add-to-cart", function (e) {
  e.preventDefault();
  
  var sellingPlan = $(e.target).closest('.shopify-product-form').find('.subscription-options option:selected')?.attr('data-selling-plan-name');

  // main product object
  var data = [];
  var val = $(e.target).closest('.shopify-product-form').find('input[name="id"]').attr('value');
  console.log(val)
  var main_product = { 
    id: val, 
    quantity: 1,
    properties:{
      selling_plan: sellingPlan
    }
  };

  data.push(main_product);
  // Add metafield products if added
    $(".metafield-product").each((i, product) => {
    var check = $(product).find("#imageCheckbox").is(":checked");
    if (check) {
      var id = parseInt($(product).find("#imageCheckbox").attr("data-id"));
      var item = {
        id: id,
        quantity: 1,
      };
      data.push(item);
    }
  });
  // AJAX call to add the product to the cart
  $.ajax({
  url: "/cart/add.js",
  data: JSON.stringify({ items: data }),
  type: "POST",
  dataType: "json",
  contentType: "application/json",
  success: function (response) {
    console.log("Add to cart success", response);
      updateCart();
      changeCount();
      updateCartTotal();
      recommendations();
      setTimeout(function () {
        $(".mini-cart").addClass("active-cart");
        $("body").addClass("active-cart");
      }, 300);
  },
  error: function (error) {
    console.error("Error adding to cart:", error);
  },
});
});


//updateQty

// $("body").on("click", ".qty-box span.qty ", function (event) {
//   var qtybox = $(event.target).parent(".qty-box");
//   var field = qtybox.find("input.qty-btn");
//   var value = parseInt(field.val());

//   if ($(event.target).hasClass("plus")) {
//     field.val(value + 1);
//   } else if ($(event.target).hasClass("minus")) {
//     if (value > 1) {
//       field.val(value - 1);
//     }
//   }

//   var productid = field.attr("id");
//   var quantity = parseInt(field.val());
//   $.ajax({
//     type: "POST",
//     url: "/cart/change.js",
//     data: {
//       id: productid,
//       quantity: quantity,
//     },
//     dataType: "json",
//     success: function (data) {
//       console.log("update");
//       updateCart();
//       changeCount();
//       recommendations();
//       updateFreeShippingBar();
//       bundle();
//     },
//     error: function (error) {
//       $(qtybox)
//         .closest(".cart-items")
//         .append(
//           `<span class="error active">${error.responseJSON.message}</span>`
//         );
//       setTimeout(() => {
//         updateCart();
//       }, 500);
//     },
//   });
// });
$("body").on("click", ".qty-box span.qty", function (event) {
  var qtybox = $(event.target).parent(".qty-box");
  var field = qtybox.find("input.qty-btn");
  var value = parseInt(field.val());

  // Increment or Decrement Quantity
  if ($(event.target).hasClass("plus")) {
    field.val(value + 1);
  } else if ($(event.target).hasClass("minus")) {
    if (value > 1) {
      field.val(value - 1);
    }
  }
  
  var itemKey = field.attr("data-key"); 
  var bundleId = field.attr("data-bundle-id");
  var quantity = parseInt(field.val());

  // Check if the product is part of a bundle
  if (bundleId) {
    // Update all
    console.log(`Updating bundle: ${bundleId} to quantity: ${quantity}`);
    updateBundleQuantities(bundleId, quantity);
  } else {
    // Update single item
    console.log(`Updating single item: ${itemKey} to quantity: ${quantity}`);
    $.ajax({
      type: "POST",
      url: "/cart/update.js",
      contentType: "application/json",
      data: JSON.stringify({
        updates: {
          [itemKey]: quantity
        }
      }),
      dataType: "json",
      success: function (data) {
        console.log("Single item updated", data);
        updateCart();
        changeCount();
        updateFreeShippingBar();
        bundle();
      },
      error: function (error) {
        $(qtybox)
          .closest(".cart-items")
          .append(
            `<span class="error active">${error.responseJSON.message}</span>`
          );
        setTimeout(() => {
          updateCart();
        }, 500);
      },
    });
  }
});


//remove items from cart
// $("body").on("click", ".remove-cart-item .remove_item", function (e) {
//   e.preventDefault();
//   $.ajax({
//     type: "POST",
//     url: "/cart/change.js",
//     data: {
//       id: $(e.target).attr("data-id"),
//       quantity: 0,
//     },
//     dataType: "json",
//     success: function (data) {
//       console.log("item removed", data);
//       updateCart();
//       changeCount();
//       recommendations();
//       updateFreeShippingBar();
//     },
//     error: function (error) {
//       console.log(error.responseJSON.message);
//     },
//   });
// });

$("body").on("click", ".remove_item", function (e) {
  e.preventDefault();

  var target = $(e.target);
  var itemKey = target.attr("data-id"); //key for single item
  var bundleId = target.attr("data-bundle-id"); // _bundle_id for bundles

  if (bundleId) {
    // Remove all items in the bundle
    console.log(`Removing bundle with ID: ${bundleId}`);
    removeBundleItems(bundleId);
  } else {
    // Remove single item
    console.log(`Removing single item with key: ${itemKey}`);
    removeSingleItem(itemKey);
  }
});

// Function to remove a single cart item
function removeSingleItem(itemKey) {
  $.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: {
      id: itemKey,
      quantity: 0,
    },
    dataType: "json",
    success: function (data) {
      console.log("Item removed successfully", data);
      updateCart();
      changeCount();
      recommendations();
      updateFreeShippingBar();
    },
    error: function (error) {
      console.log(error.responseJSON.message);
    },
  });
}
// Recommendation section

var current_product = $(".pdp-inner");
  if (current_product) {
  var id = parseInt($('.shopify-product-form [name="product-id"]').val());
  $.get(`/recommendations/products?product_id=${id}&section_id=product-recommendation`,function (data) {
      // console.log(data)
      $(".recommendations-container").html($(data).find(".recommendations-container").html());
      $(".section-recommendation .pr-shop-btn .btn-bg-border span").text($(".recommendations-container .product-card-main").attr("data-button"));
      initializeRecSlick();
    });
}
  function initializeRecSlick() {
  var slider = $(".recommendations-container .new-ar-inner");
  if (slider.hasClass("slick-initialized")) {
    slider.slick("unslick");
  }
  slider.slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    infinite: false,
    dots: true,
    arrows: true,
    responsive: [
        {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  });
}

// Cart Recommendations
function recommendations() {
    $.getJSON("/cart.js", function (cart) {
      if (cart.items.length > 0) {
        var productIds = cart.items.map(function (item) {
          return parseInt(item.product_id);
        });

        // Get recommendations based on the first product in the cart
        $.get(`/recommendations/products?product_id=${productIds[0]}&section_id=product-recommendation`, function (data) {
          $(".recommendations-container").html($(data).find(".recommendations-container").html());
          $(".recommendations-container .pr-shop-btn .btn-bg-border span").text($(".product-card-main").attr("data-button"));
          initializeRecSlick();

          // If the cart is open (active-cart), update recommendations in the mini-cart
          if ($("body").hasClass("active-cart")) {
            $("#cart-recommendations").html($(data).find(".recommendations-container").html());
            $(".recommendations-container .pr-shop-btn .btn-bg-border span").text($(".product-card-main").attr("data-button"));
            $("#cart-recommendations .new-ar-inner").slick({
              slidesToShow: 3,
              slidesToScroll: 1,
              infinite: false,
              dots: true,
              arrows: false,
              responsive: [
                {
                  breakpoint: 1024,
                  settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                  },
                },
                {
                  breakpoint: 768,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                  },
                },
                {
                  breakpoint: 480,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                  },
                },
              ],
            });
          }
        });
      }
    });
}

recommendations();
// CONTACT FORM VALIDATION
$(document).ready(function () {
  $("#submitBtn").on("click", function (event) {
    event.preventDefault();
    
    const name = $("#name").val().trim();
    const email = $("#email").val().trim();
    const message = $("#message").val().trim();
    let isValid = true;
    $(".input-wrapper").removeClass("error");
    
    if (name === "") {
      isValid = false;
      $("#name").closest(".input-wrapper").addClass("error");
    }
    
    if (email === "") {
      isValid = false;
      $("#email").closest(".input-wrapper").addClass("error");
      alert("Please enter your email.");
    } else if (!validateEmail(email)) {
      isValid = false;
      $("#email").closest(".input-wrapper").addClass("error");
    }

    if (message === "") {
      isValid = false;
      $("#message").closest(".input-wrapper").addClass("error");
    }

    if (isValid) {
      $("#contactForm").submit();
    }
  });
  
  function validateEmail(email) {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return emailRegex.test(email);
  }
});

// comment form
$("#comment_form").on("submit", function (event) {
  event.preventDefault();
  $(".new-comment input , .new-comment textarea").each((index, field) => {
    $(field).next().removeClass("active");
    if ($(field).val() == "") {
      $(field).next().addClass("active");
    }
    // email validation
    if ($(field).attr("name") == "email") {
      var emailVal = $(field).val().trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        $(field).next().addClass("active");
      }
    }
  });

  if (!document.querySelector(".new-comment .error.active")) {
  }
});
// Predictive Search
const searchInput = $("#search-input");
const searchResultsContainer = $("#search-results");
let timeout;

$(searchInput).on("input", () => {
  clearTimeout(timeout);
  timeout = setTimeout(fetchPredictiveSearchResults, 1000);
});

function fetchPredictiveSearchResults() {
  const query = searchInput.val().trim();
  if (!query) return hideSearchResults();
  $.get(`/search/suggest.json?q=${encodeURIComponent(query)}`,function (data) {
      displayResults(data.resources.results.products);
      displayResults(data.resources.results.pages);
      displayResults(data.resources.results.collections);
    }
  );
}

function displayResults(products) {
  searchResultsContainer.html(
    products.length > 0 ? `<div class="search-content"><div class="search-wrapper">${products.map((product) =>
              `<a href="${product.url}" class="search-inner">
                <img src="${product.featured_image.url}" alt="${product.title}" />
                <span class="title">${product.title}</span>
               </a>`).join("")}</div></div>`
          : "<p>No results found</p>"
  );
  showSearchResults();
}

function showSearchResults() {
  searchResultsContainer.css("display", "block");
  $("body").addClass("no-scroll");
}

function hideSearchResults() {
  searchResultsContainer.css("display", "none");
  $("body").removeClass("no-scroll");
}

$("body").on("click", (e) => {
  if (!$(e.target).is(searchResultsContainer) && !$(e.target).is(searchInput)) {
    hideSearchResults();
  }
});

// Free Shipping bar
const freeShippingThreshold = parseFloat($("#free-shipping-bar").data("free-shipping-threshold")) || 100; 
function updateFreeShippingBar(cartTotal) {
  const freeShippingFill = $(".free-shipping-bar-fill");
  const freeShippingMessage = $(".free-shipping-message");
  const cartTotalFloat = cartTotal / 100;
  const percentage = Math.min((cartTotalFloat / freeShippingThreshold) * 100, 100);
  freeShippingFill.css("width", `${percentage}%`);
  if (cartTotalFloat < freeShippingThreshold) {
    const remainingAmount = (freeShippingThreshold - cartTotalFloat);
    freeShippingMessage.html(`Spend Rs.${remainingAmount} more to get free shipping!`);
  } else {
    freeShippingMessage.html("Congratulations! You are eligible for free shipping!");
  }
}

function updateCartTotal() {
  $.getJSON("/cart.js", function (cart) {
    updateFreeShippingBar(cart.total_price);
  });
}
$(document).ready(function () {
  updateCartTotal();
});


// sort_by
$("body").on("click", ".sort-wrapper .sort-by .sort-label li input", (e) => {
  var sortVal = $(e.target).val();
  var url = new URL(window.location.href);
  var searchParams = url.searchParams;
  searchParams.set("sort_by", sortVal);
  var newUrl = `${url.pathname}?${searchParams.toString()}`;
  window.history.pushState(null, "", newUrl);
  $.get(newUrl, (data) => {
    $(".collection-wrapper .col-collections , .search .col-collections ").html(
      $(data).find(".col-collections").html()
    );
    $(
      ".collection-wrapper .col-filter .filter-inner, .search .filter-inner"
    ).html($(data).find(".filter-inner").html());
  });
});

// Price range slider
$(document).ready(function () {
  const fromSlider = $("#fromSlider");
  const toSlider = $("#toSlider");
  const sliderTrack = $(".sliders_control");
  const minGap = 100; // Minimum gap between the sliders

  function updateSliderValues() {
    const min = parseInt(fromSlider.attr("min"));
    const max = parseInt(fromSlider.attr("max"));

    if (parseInt(toSlider.val()) - parseInt(fromSlider.val()) <= minGap) {
      fromSlider.val(parseInt(toSlider.val()) - minGap);
    }

    if (parseInt(toSlider.val()) - parseInt(fromSlider.val()) <= minGap) {
      toSlider.val(parseInt(fromSlider.val()) + minGap);
    }

    const percentFrom = ((fromSlider.val() - min) / (max - min)) * 100;
    const percentTo = ((toSlider.val() - min) / (max - min)) * 100;

    sliderTrack.css("background","linear-gradient(to right, #ddd ${percentFrom}%, #007bff ${percentFrom}%, #007bff ${percentTo}%, #ddd ${percentTo}%)");
  }

  fromSlider.on("input", updateSliderValues);
  toSlider.on("input", updateSliderValues);

  updateSliderValues();
});

// Storefront Filters
function updateFilters() {
  const searchParams = new URLSearchParams(window.location.search);
  const fromPrice = $("#fromSlider").val();
  const toPrice = $("#toSlider").val();
  if (fromPrice) {
    searchParams.set("filter.v.price.gte", fromPrice)
  }
  if (toPrice){ 
    searchParams.set("filter.v.price.lte", toPrice)
      }

  $(".filter-var ul li input:checked").each((index, el) => {
    const filterName = $(el).attr("name").trim();
    const filterValue = $(el).val().trim();
    searchParams.set(filterName, filterValue);
  });

  const newUrl = `${window.location.pathname}?${searchParams.toString()}`;
  console.log("New URL:", newUrl);

  $.get(newUrl, (data) => {
    if (data.length > 0) {
      $(".collection-wrapper .col-collections, .search .col-collections").html($(data).find(".col-collections").html());
      $(".collection-wrapper .filter-inner , .search .filter-inner").html($(data).find(".filter-inner").html());
    }
    else{
    console.log("No products found");   
    }
  });
  window.history.pushState(null, "", newUrl);
}

$("body").on("change",".filter-var ul li input[type='checkbox']", updateFilters);
$("body").on("change", "#fromSlider, #toSlider", function () {
  const fromValue = $("#fromSlider").val();
  const toValue = $("#toSlider").val();
  $("#fromInput").val(fromValue);
  $("#toInput").val(toValue);
  updateFilters();
});

$("body").on("change", "#fromInput, #toInput", function () {
  const fromValue = $("#fromInput").val();
  const toValue = $("#toInput").val();
  $("#fromSlider").val(fromValue);
  $("#toSlider").val(toValue);
  updateFilters();
});

// Clear All Filters
$("body").on("click", "#clear-filters", function () {
  const url = `${window.location.pathname}`;
  window.history.pushState(null, "", url);
  location.reload();
});

$(document).ready(function () {
  const searchParams = new URLSearchParams(window.location.search);
  if (searchParams.has("filter.v.price.gte")) {
    const fromPrice = searchParams.get("filter.v.price.gte");
    $("#fromSlider").val(fromPrice);
    $("#fromInput").val(fromPrice);
  }
  if (searchParams.has("filter.v.price.lte")) {
    const toPrice = searchParams.get("filter.v.price.lte");
    $("#toSlider").val(toPrice);
    $("#toInput").val(toPrice);
  }
});

// load-more button collection-page

let isLoading = false;
$(document).ready(function () {
  const loadMoreButton = $("#load-more");
  const productGrid = $(".collection-wrapper .col-collection-inner");

  if (loadMoreButton.length) {
    loadMoreButton.on("click", function () {
      if (isLoading) return;
      const nextPageUrl = loadMoreButton.data("next-page");

      if (nextPageUrl) {
        isLoading = true;
        loadMoreButton.prop("disabled", true).text("Loading...");

        $.get(nextPageUrl, (data) => {
          const newProducts = $(data).find(".col-collection-inner .product-card");
          productGrid.append(newProducts);
          const newNextPageUrl = $(data).find("#load-more").data("next-page");
          if (newNextPageUrl) {
            loadMoreButton.data("next-page", newNextPageUrl);
            loadMoreButton.prop("disabled", false).text("Load More");
          } else {
            loadMoreButton.remove();
          }
          isLoading = false;
        });
      }
    });
  }
});

// On-scroll loading collection-page
if ($("body").hasClass("template-collection")) {
  let isLoading = false;
  $(window).on("scroll", function () {
    const colNext = $(".collection-wrapper #next-page");
    const colTop = $(".collection-wrapper").offset().top;
    const colHeight = $(".collection-wrapper").outerHeight();
    const colBottom = colTop + colHeight;
    const pageScroll = window.scrollY + window.innerHeight;

    if (isLoading || !colNext.length) return;
    if (pageScroll > colBottom) {
      isLoading = true;
      colNext.addClass("disable");
      $(".collection-wrapper .loader").show();
      $.get(colNext.attr("href"), function (data) {
        const newContent = $("<div>").html(data);
        const newProducts = newContent.find(".col-collection-inner .normal-product");
        const newNextPage = newContent.find("#next-page");
        $(".col-collection-inner").append(newProducts);
        if (newNextPage.length) {
          colNext.attr("href", newNextPage.attr("href")).removeClass("disable");
        } else {
          colNext.remove();
          $(window).off("scroll");
        }
        $(".collection-wrapper .loader").hide();
        isLoading = false;
      });
    }
  });
}

// recently viewed using Cookies
if ($("body").hasClass("template-product")) {
  var currentProductHandle = $(".pdp-inner").data("handle");
  console.log("Current Product Handle:", currentProductHandle);
  addProduct(currentProductHandle);
    renderProducts();

  function addProduct(productHandle) {
    var viewedProducts = getProducts();
    console.log("Viewed Products (Before):", viewedProducts);
    var index = viewedProducts.indexOf(productHandle);
    if (index > -1) {
      viewedProducts.splice(index, 1);
      console.log("Updated-array:", viewedProducts);
    }
    if (viewedProducts.length >= 6) {
      viewedProducts.pop(productHandle);
      console.log("Updated-array:", viewedProducts);
    }
    viewedProducts.unshift(productHandle);
    console.log(viewedProducts);
    Cookies.set("recently_viewed_products", JSON.stringify(viewedProducts), {
      expires: 30,
      path: "/",
    });
    console.log("after-set", viewedProducts);
    if (viewedProducts.length === 0 || (viewedProducts.length === 1 && viewedProducts[0] === currentProductHandle)){
      $("#recently-viewed-container").hide();
  }
}

  function getProducts() {
    var viewedProducts = [];
    var cookie = Cookies.get("recently_viewed_products");
    console.log("after-get:", cookie);
    if (cookie) {
      viewedProducts = JSON.parse(cookie);
    }
    return viewedProducts;
  }
  function renderProducts() {
  var viewedProducts = getProducts();
  console.log("Viewed Products:", viewedProducts);

  var productCount = 0;
  viewedProducts.forEach(function (productHandle, index) {
    if (productHandle !== currentProductHandle) {
      $.get(`/products/${productHandle}?section_id=wishlist-product`, function (data) {
        // console.log("Fetched Data:", data);
       // Hide the section when no recently-viewed-products
        $("#recently-viewed-products").prepend($(data).find(".product-container").html());
        productCount++;
        console.log("Product Count:", productCount, productCount === (viewedProducts.length - 1), viewedProducts.length);
        // if (productCount === viewedProducts.length || productCount >= 3) {
        if (productCount === (viewedProducts.length - 1)) {
          initializeSlick();
        }
      });
    }
  });
}
// Initialize Slick Slider

function initializeSlick() {
  var slider = $("#recently-viewed-products.new-ar-inner");
  if (slider.hasClass("slick-initialized")) {
    slider.slick("destroy");
  }
  slider.slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    infinite: false,
    dots: false,
    arrows: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  });
}
}

// recently viewed using localStorage
// if(("body").hasClass("template-product")){
//     var currentProductHandle = $(".pdp-inner").data("handle");
//     console.log("Current Product Handle:", currentProductHandle);
//     addProduct(currentProductHandle);
//     renderProducts();
//     function addProduct(productHandle) {
//         var viewedProducts = getProducts();
//         console.log("Viewed Products (Before):", viewedProducts);
//         var index = viewedProducts.indexOf(productHandle);
//         if (index > -1) {
//             viewedProducts.splice(index, 1);
//             console.log("Duplicate Handle:", viewedProducts);
//         }
//         if (viewedProducts.length >= 5) {
//             viewedProducts.pop();
//             console.log("Removed", viewedProducts);
//         }
//         viewedProducts.unshift(productHandle);
//         console.log("Updated:", viewedProducts);
//         localStorage.setItem('recently_viewed_products', JSON.stringify(viewedProducts));
//         console.log("Stored:", viewedProducts);
//     }

//     function getProducts() {
//         var viewedProducts = [];
//         var storedData = localStorage.getItem('recently_viewed_products');
//         console.log("Retrieved:", storedData);

//         if (storedData) {
//             try {
//                 viewedProducts = JSON.parse(storedData);
//             } catch (error) {
//                 console.error("Error", error);
//             }
//         }
//         return viewedProducts;
//     }
//     function renderProducts() {
//           var viewedProducts = getProducts();
//         console.log("Viewed Products:", viewedProducts);
//         viewedProducts.forEach(function (productHandle) {
//             $.get(`/products/${productHandle}.json`, function (data) {
//                 console.log("Product Data:", data);
//                 var product = data.product;
//               var variant = data.product.variants[0];
//               if (productHandle !== currentProductHandle && productHandle !== null) {
//                 var product = `
//                     <div class="cm-ar-pr">
//                       <div class="product-card">
//                           <div class="product-image">
//                             <a href="/products/${product.handle}">
//                               <img src="${product.images[0].src}" alt="${product.title}">
//                             </a>
//                           </div>
//                           <div class="product-content">
//                             <div class="product-details">
//                               <h3 class="product-name">${product.title}</h3>
//                               <div class="sh1 price">Rs.${variant.price}</div>
//                               <a href="/products/${product.handle}" class="btn-bg-border">
//                                 <span>Visit Again</span>
//                               </a>
//                             </div>
//                           </div>
//                       </div>
//                     </div>`;
//                 $("#recently-viewed-products.new-ar-inner").append(productData);
//                   }
//             });
//         });
//     }
// };


// product-bundle
function bundle() {
  $(".bundle-container").on("change", "input[name='bundle-products']", function () {
    var group = $(this).closest(".bundle-item").find("input[name='bundle-products']");
    if ($(this).prop("checked")) {
      group.not($(this)).prop("checked", false);
    }
    updateStepBoxes();
  });

  $(".bundle-container #apply-bundle-btn").on("click", function () {
    const selectedProducts = [];

    // Step-1: Main Product Selection
    const mainProductSelected = $('.main-product input[name="bundle-products"]:checked');
    if (mainProductSelected.length === 0) {
      console.log("No main product selected");
      return;
    }
    selectedProducts.push(mainProductSelected.data('product-id'));

    // Step-2: Complementary Product Selection
    const addProductSelected = $('.add-product input[name="bundle-products"]:checked');
    if (addProductSelected.length === 0) {
      console.log("No complementary product selected");
    } else {
      selectedProducts.push(addProductSelected.data('product-id'));
    }

    // Step-3: Freebie Product Selection
    const freeProductSelected = $('.free-product input[name="bundle-products"]:checked');
    if (freeProductSelected.length === 0) {
      console.log("No freebie product selected");
    } else {
      selectedProducts.push(freeProductSelected.data('product-id'));
    }
    console.log(selectedProducts);
    if (selectedProducts.length === 0) {
      console.log("No products selected");
      return;
    }
    // BUNDLE ID 
    const bundleId = `bundle_${Date.now()}`;
    console.log("bundle Id:", bundleId);
    const items = selectedProducts.map(productId => ({
      id: productId,
      quantity: 1,
      properties: {
        _bundle_id: bundleId
      }
    }));
    console.log(items)
    $.ajax({
      url: '/cart/add.js',
      method: 'POST',
      contentType: "application/json",
      data: JSON.stringify({items}),
      success: function () {
        console.log('Bundle added successfully');
        updateCart();
        recommendations();
        
        setTimeout(function () {
          $(".mini-cart").addClass("active-cart");
          $("body").addClass("active-cart");
        }, 300);
      },
      error: function (error) {
        console.log("Error adding bundle", error);
      }
    });
  });
}

// Update Step Boxes Based on Selection
function updateStepBoxes() {
  $('.step-box').empty();

  // Step 1: Main Product
  const mainProduct = $('.main-product input[name="bundle-products"]:checked');
  updateStepBox($('.step').eq(0).find('.step-box'), mainProduct);

  // Step 2: Complementary Product
  const addProduct = $('.add-product input[name="bundle-products"]:checked');
  updateStepBox($('.step').eq(1).find('.step-box'), addProduct);

  // Step 3: Freebie
  const freeProduct = $('.free-product input[name="bundle-products"]:checked');
  updateStepBox($('.step').eq(2).find('.step-box'), freeProduct);
}

function updateStepBox(stepBox, productInput) {
  if (productInput.length > 0) {
    const productImage = productInput.siblings('img').attr('src');
    const productTitle = productInput.siblings('h4').text();

    stepBox.html(`
      <div class="selected-product">
          <img src="${productImage}" alt="${productTitle}">
          <h4>${productTitle}</h4>
      </div>
    `);
  } else {
    stepBox.empty();
  }
}
$(document).ready(function () {
  bundle();
});


// Update all bundle items
function updateBundleQuantities(bundleId, quantity) {
  $.getJSON('/cart.js', function(cart) {
    const updates = {};
    cart.items.forEach(item => {
      if (item.properties && item.properties._bundle_id === bundleId) {
        updates[item.key] = quantity;
      }
    });
    console.log(updates)
    if (Object.keys(updates).length === 0) {
      console.log('No bundle items found.');
      return;
    }

    $.ajax({
      type: 'POST',
      url: '/cart/update.js',
      contentType: 'application/json',
      data: JSON.stringify({ updates }),
      dataType: 'json',
      success: function(data) {
        console.log('Bundle quantities updated', data);
        updateCart();
        changeCount();
        recommendations();
        updateFreeShippingBar();
      },
      error: function(error) {
        console.log('Error', error);
      }
    });
  });
}

// Remove all bundle items
function removeBundleItems(bundleId) {
  $.getJSON('/cart.js', function(cart) {
    const updates = {};
    cart.items.forEach(item => {
      if (item.properties && item.properties._bundle_id === bundleId) {
        updates[item.key] = 0;
      }
    });

    if (Object.keys(updates).length === 0) {
      console.log('No bundle items found to remove.');
      return;
    }
    $.ajax({
      type: 'POST',
      url: '/cart/update.js',
      contentType: 'application/json',
      data: JSON.stringify({ updates }),
      dataType: 'json',
      success: function(data) {
        console.log('Bundle items removed successfully', data);
        updateCart();
        changeCount();
        recommendations();
        updateFreeShippingBar();
      },
      error: function(error) {
        console.log('Error', error);
      }
    });
  });
}

// Quick-view-product
 $("body").on("click", ".quick-view-btn", function(t){
   t.preventDefault();
    var quickButton = $(t.target);
    quickButton.addClass("active");
    var productHandle = quickButton.attr("data-product-handle");
    var quickModal = quickButton.parents().find(`#quick-modal-${productHandle}`);
    console.log("Modal:", quickModal);
    $.get(`/products/${productHandle}?section_id=main-product`, function(data){
      if(quickModal.length > 0){
        quickModal.addClass("active");
      }
    })
  });
  $("#quick-modal-product-variants .variant-part ul li input[type='radio']").on("change",  function(){
    var selectedOptions1 = [];
    $("#quick-modal-product-variants .variant-part ul li input:checked").each(function(index,input){
       selectedOptions1.push($(input).val());
      console.log(selectedOptions1);
    });
    var quickView = $(this).closest('.quick-modal');
    var product = quickView.find(".product-card").attr("data-product-handle");
    $.getJSON(`/products/${product}.js`, function(data){
      var productData = data;
      if(productData){
        productData.variants.forEach(variant => {
          if(JSON.stringify(variant.options).includes(JSON.stringify(selectedOptions1))){
            quickView.find('input[name="id"]').val(variant.id);
            if(variant.featured_image){
              quickView.find('#quick-modal-product-details .product-card .product-image img').attr('src',variant.featured_image.src)
            }
          }
        })
      }
    });
  }); 
  $("body").on("click","#quick-modal-close", function () {
    console.log("closed");
      $(this).closest(".quick-modal").removeClass("active");
    }); 
   
// // Cart-drawer Edit button

//   $("body").on("click", "#cart-edit", function (event) {
//   event.preventDefault();
//   var target = $(event.target);
//   $("#cart-edit").removeClass("active");
//   target.addClass("active");
//   var item = target.attr("data-handle");
//   console.log("target:", target);
//   console.log("Product name:", item);
//   $.getJSON(`/products/${item}.js`, function(data){
//     target.siblings(".quick-view-modal").addClass("active");
//   });
// });
// const variant = JSON.parse($('[data-selected-variant]').html());
// quickViewProduct();
// function quickViewProduct(){
//   $(document).on("click","#quick-view-close", function () {
//       $(this).closest(".quick-view-modal").removeClass("active");
//     });
//     $("body").on("change", "#quick-view-product-variants .variant-part ul li input[type='radio']", function(){
//     var selectedOptions1 = [];
//     $('#quick-view-product-variants .variant-part ul li input[type="radio"]:checked').each(function(i,input){
//        selectedOptions1.push($(input).val());
//     });
//     console.log(selectedOptions1)
//       $(variant).each((i,variant)=>{
//           if(JSON.stringify(variant.options) == JSON.stringify(selectedOptions1))
//            $.get(`?variant=${variant.id}`,(data)=>{
//           var quickView = $(this).closest('.quick-view-modal');
//           quickView.find('.quick-view-form input[name="id"]').val(variant.id);
//       if(variant.featured_image){
//       quickView.find('#quick-view-product-details .product-card .product-image img').attr('src',variant.featured_image.src)
//       }
//       quickView.find('#quick-view-product-details .product-card .product-content .product-details .product-name').html(variant.name);
//       quickView.find('#quick-view-product-details .product-card .product-content .product-details .price .sh1').text(Shopify.formatMoney(variant.price).replace("$", "Rs."));
//     });
// });
// });
// }

// Cart-edit functionality
$(document).on("click", "#cart-edit", function (event) {
  event.preventDefault();
  var target = $(event.target);
  $("#cart-edit").removeClass("active");
  target.addClass("active");
  var item = target.attr("data-handle");
  console.log("target:", target);
  console.log("Product name:", item);
  $.getJSON(`/products/${item}.js`, function(data){
    target.siblings(".quick-view-modal").addClass("active");
    quickViewProduct();
  });
});
quickViewAddCart();
quickViewProduct();

function quickViewProduct(){
  $(document).on("click","#quick-view-close", function () {
      $(this).closest(".quick-view-modal").removeClass("active");
    });
    $("body").on("change", "#quick-view-product-variants .variant-part ul li input[type='radio']", function(){
    var selectedOptions1 = [];
    $('#quick-view-product-variants .variant-part ul li input[type="radio"]:checked').each(function(i,input){
       selectedOptions1.push($(input).val());
    });
    var quickView = $(this).closest('.quick-view-modal');
    var product = quickView.find(".product-card").attr("data-product-handle");
    $.getJSON(`/products/${product}.js`, function(data){
      var productData = data;
      if(productData){
        productData.variants.forEach(variant => {
          if(JSON.stringify(variant.options).includes(JSON.stringify(selectedOptions1))){
            console.log(JSON.stringify(variant.options));
            console.log(JSON.stringify(selectedOptions1));
            
            quickView.find('.quick-view-form input[name="id"]').val(variant.id);
            if(variant.featured_image){
            quickView.find('#quick-view-product-details .product-card .product-image img').attr('src',variant.featured_image.src)
            }
            quickView.find('#quick-view-product-details .product-card .product-content .product-details .product-name').html(variant.name);
            quickView.find('#quick-view-product-details .product-card .product-content .product-details .price .sh1').text(Shopify.formatMoney(variant.price).replace("$", "Rs."));
          }
        })
      }
    });
  }); 
}

function quickViewAddCart(){
  $("body").on("submit", ".quick-view .quick-view-form", function (h) {
  h.preventDefault();
  var form = $(this);
  var newVariantId = form.find('input[name="id"]').val();
  var cartEditButton = form.parents().find("#cart-edit.active");
  console.log("Edit Button: " , cartEditButton)
  var itemId = cartEditButton.attr("data-id");
  console.log("New Variant ID:", newVariantId);
  console.log("Old Variant ID:", itemId);

  // Update the cart
  $.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: {
      id: itemId,
      quantity: 0,
    },
    dataType: "json",
    success: function () {
      $.ajax({
        type: "POST",
        url: "/cart/add.js",
        data: {
          id: newVariantId,
          quantity: 1, 
              },
        dataType: "json",
        success: function () {
          updateCart();
        },
        error: function () {
          console.log("Error updating the cart.");
        }
      });
    },
    error: function () {
      alert("Error removing the old variant.");
    }
  });
});
}

// Product Compare
$(document).ready(function () {
    let compareList = JSON.parse(localStorage.getItem('compareList')) || [];
    function updateCompareButtons() {
        $('.compare-btn').each(function () {
            var product = $(this).data('product');
            let productId = product.id;
            if (compareList.some(p => p.id === productId)) {
                $(this).text('Remove From Compare');
            } else {
                $(this).text('Compare');
            }
        });

        // Update compare count
        $("#compare-count").text(compareList.length);
    }
    $("body").on("click", ".compare-btn", function (e) {
        let target = $(e.target);
        let product = JSON.parse(target.attr("data-product"));
        let index = compareList.findIndex(p => p.id === product.id);
        if (index > -1) {
            compareList.splice(index, 1);
        } else {
            if (compareList.length < 3) { 
                compareList.push(product);
            } else {
                alert("You can compare up to 3 products only. Remove any product from the list to compare further.");
            }
        }
        localStorage.setItem('compareList', JSON.stringify(compareList));
        updateCompareButtons();
    });
    let compareContainer = $('#compare-products');
    if (compareList.length !== 0) {
      let html = '<table class="compare-table" border="0">';
      // Row for images
      html += '<tr><td></td>';
      compareList.forEach(product => {
          html += 
            `<td>
                <a href="/products/${product.handle}">
                    <img src="${product.featured_image}" alt="${product.title}" style="max-width:200px;"><br>        
                </a>
              </td>`;
              });
              html += '</tr>';
        
        // Row for titles
        html += '<tr class="bg"><td>Title</td>';
        compareList.forEach(product => {
            html += `<td>${product.title}</td>`;
        });
        html += '</tr>';

        // Row for description
        html += '<tr><td>Description</td>'
        compareList.forEach(product => {
          html +=`<td>${product.description}</td>`
        })
        // Row for prices & remove buttons
        html += '<tr class="bg"><td>Price</td>';
        compareList.forEach(product => {
            html += `
              <td>
                <p>Rs.${product.price}</p>
              </td>`;
        });
        html += '</tr>';

       html += '<tr><td>Options</td>';
        compareList.forEach(product => {
            html += `<td>${product.options}</td>`;
        });
        html += '</tr>';

      html += '<tr><td></td>';
        compareList.forEach(product => {
            html += `<td><button class="remove-compare btn-bg-border" data-product-id="${product.id}">Remove From Compare</button></td>`;
        });
        html += '</tr>';
        html += '</table>';
        compareContainer.html(html);
    }

    // Handle product removal
    $("body").on('click', '.remove-compare', function () {
        let productId = $(this).data('product-id');
        compareList = compareList.filter(p => p.id != productId);
        localStorage.setItem('compareList', JSON.stringify(compareList));
        location.reload();
    });
    updateCompareButtons();
});

class predictiveSearch extends HTMLElement {
  constructor() {
    super();
    this.input = this.querySelector('input[type="search"]');
    this.predictiveSearchResults = this.querySelector('#predictive-search');
    this.input.addEventListener('input', this.debounce((event) => {
      this.onChange(event);
    }, 300).bind(this));
  }

  onChange() {
    const searchTerm = this.input.value.trim();
    if (!searchTerm.length) {
      this.close();
      return;
    }
    this.getSearchResults(searchTerm);
  }

  getSearchResults(searchTerm) {
    fetch(`/search/suggest?q=${searchTerm}&section_id=predictive-search`)
      .then((response) => {
        if (!response.ok) {
          var error = new Error(response.status);
          this.close();
          throw error;
        }
        return response.text();
      })
      .then((text) => {
        const resultsMarkup = new DOMParser().parseFromString(text, 'text/html').querySelector('#shopify-section-predictive-search').innerHTML;
        this.predictiveSearchResults.innerHTML = resultsMarkup;
        this.open();
      })
      .catch((error) => {
        this.close();
        throw error;
      });
  }
  open() {
    this.predictiveSearchResults.style.display = 'block';
  }
  close() {
    this.predictiveSearchResults.style.display = 'none';
  }
  debounce(fn, wait) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }
}
customElements.define('predictive-search', predictiveSearch);